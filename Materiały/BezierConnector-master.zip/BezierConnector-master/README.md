# Bézier Connector

This sample app demonstrates how you can use the Win2d APIs to draw a dynamic Bézier connector.

<img src="https://user-images.githubusercontent.com/7021835/51359005-b8b4bc80-1aeb-11e9-8e58-edb503095907.gif" />